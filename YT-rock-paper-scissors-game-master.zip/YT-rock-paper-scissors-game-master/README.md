# Rock,Paper, Scissors game
Implementation for the popular rock, paper, scissors game. It's basically a challenge from frontendmentor.io website.

- Check the challenge page [here](https://www.frontendmentor.io/challenges/rock-paper-scissors-game-pTgwgvgH)
- Check the live website [here](https://scissors-paper-rock-game.netlify.app/)
